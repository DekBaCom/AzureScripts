$storage_account = Get-AzStorageAccount
$ctx = $storage_account.Context 

foreach($storageAcc in $ctx)  
 {


$blobs = Get-AzureStorageContainer -Context $storageAcc | Get-AzStorageBlob 

foreach ($blob in $blobs)
{
    $cons = Get-AzureStorageContainer -Context $storageAcc 
   
    Write-Output $storageAcc.Name  ","  $cons.Name  ","  $blob.Name  ","  $blob.BlobType  ","  $blob.ContentType  ","  $blob.Length | Out-File -Append -NoNewline -Path .\AzureStorage.csv
    Write-Output "" | Out-File -Append -Path .\AzureStorage.csv
    
  
}

 }



