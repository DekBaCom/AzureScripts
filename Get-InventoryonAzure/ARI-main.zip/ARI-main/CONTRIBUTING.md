---

---

# Contributing

*Welcome and thank you for your interest
in contributing to **Azure Resource Inventory**! 

Before contributing to this project, please review this document for policies and procedures which
will ease the contribution and review process for everyone. 

If you have questions or suggestion please fell free to contact Us by mail:  **clvieira@Microsoft.com** or **Renato.Gregio@Microsoft.com**.*

## Issues and Feature Requests

If you noticed any issue (bug), similar problem, or have sugestions for improvement, please feel free to contact the project authors mentioned above. At this moment we are still evaluating how to incorporate more long term contributors.
